#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "lcd.h"

/*lcd_draw_point:在lcd上画一个点
 *x：x轴坐标   (左上角为原点，x轴分别向右，y轴下递增)
 *y：y轴坐标
 *color：点的颜色
 *lcd_ptr：LCD的操作指针
 */
void lcd_draw_point(unsigned int x, unsigned int y, unsigned int color, unsigned int *lcd_ptr)
{
	if( x>=0 && x<LCD_WIDTH && y>=0 && y<LCD_HEIGHT )
	{
		*(lcd_ptr+LCD_WIDTH*y+x) = color;
	}
}

/*lcd_draw_full_srceen_single_color:用一种颜色画满整个屏幕
 *color：点的颜色
 *lcd_ptr：LCD的操作指针
 */
void lcd_draw_full_srceen_single_color(unsigned int color, unsigned int *lcd_ptr)
{
	int x, y;
	for(y=0;y<LCD_HEIGHT;++y)
	{
		for(x=0;x<LCD_WIDTH;++x)
		{
			lcd_draw_point(x, y, color, lcd_ptr);
		}
	}
}

/*open_lcd_device:打开LCD
 *lcd_ptr：LCD的内存映射首地址
 *返回值：lcd_fd：LCD的描述符
 */
int open_lcd_device(unsigned int **lcd_ptr)
{

	int lcd_fd;
	lcd_fd = open("/dev/fb0", O_RDWR);//打开LCD设备
	if(lcd_fd == -1)
	{
		perror("open lcd device failed\n");
		return -1;
	}

	//内存映射
	*lcd_ptr = mmap( NULL, LCD_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, lcd_fd, 0);
	if(lcd_ptr == MAP_FAILED)
	{
		perror("map lcd_fb error\n");
		return -1;
	}

	return lcd_fd;
}

/*close_lcd_device:关闭LCD
 *lcd_fd：LCD的描述符
 *lcd_ptr：LCD的内存映射首地址
 */
int close_lcd_device(int lcd_fd, unsigned int *lcd_ptr)
{
	munmap(lcd_ptr, LCD_SIZE);
	return close(lcd_fd);
}
