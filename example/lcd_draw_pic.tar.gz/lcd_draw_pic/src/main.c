#include <stdio.h>
#include <stdlib.h>

#include "lcd.h"
#include "freetype.h"
#include "display_bmp.h"
#include "display_jpeg.h"

int main(int argc, char *argv[])
{
	int lcd_fd;
	int dis_ret;
	unsigned int *lcd_ptr;

	//打开LCD
	lcd_fd = open_lcd_device(&lcd_ptr);
	if(lcd_fd == -1)
	{
		return -1;
	}

	//显示bmp图片
	dis_ret = display_bmp("pic/test.bmp", lcd_ptr, 0, 0);
	if(dis_ret != 0)
	{
		printf("display bmp error\n");
	}

	printf("please enter any key continue!\n");
	getchar();

	//显示jpeg图片
	dis_ret = display_jpeg("pic/bird.jpg", lcd_ptr, 0, 0);
	if(dis_ret != 0)
	{
		printf("display jpeg error\n");
        }
	//关闭LCD
	close_lcd_device(lcd_fd, lcd_ptr);

	return 0;
}
