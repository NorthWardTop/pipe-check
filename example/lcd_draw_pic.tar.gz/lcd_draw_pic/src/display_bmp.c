#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "lcd.h"
#include "freetype.h"
#include "to_wchar.h"
#include "display_bmp.h"

/*display_bmp:显示bmp图片
 *pathname：图片的路径名
 *lcd_ptr：指向LCD映射首地址
 *x_s，y_s：左上角起始点
 */
int display_bmp(const char *pathname, unsigned int *lcd_ptr,unsigned int x_s, unsigned int y_s)
{
	unsigned int bmp_width,bmp_height;
	unsigned int x, y, color;
	unsigned char *pic_buf_ptr, *ptr_save;
	
	if( get_bmp_width_and_height( pathname, &bmp_width, &bmp_height) != 0 )//获取图片的宽高
	{
		fprintf(stderr, "get bmp width and height failed!\n");
		return -1;
	}

	if( get_pic_data_to_buffer(pathname, &pic_buf_ptr) == -1 )//获取图片的像素数据
	{
	    fprintf(stderr, "get picture data error\n");
		return -1;
	}
	ptr_save = pic_buf_ptr;
	
	for(y=y_s; y<y_s+bmp_height && y< LCD_HEIGHT; y++)
	{  
		for(x=x_s; x< x_s+bmp_width ; x++)
		{  
			if(x>=0 && x< LCD_WIDTH)
			{	    
				//将RGB的3个字节颜色数据装到4字节  RGB：红绿蓝
				color = (*(pic_buf_ptr+2)<<16) | (*(pic_buf_ptr+1)<<8) | (*pic_buf_ptr);
				lcd_draw_point(x, LCD_HEIGHT-y-1, color, lcd_ptr);//LCD_HEIGHT-y-1:镜像翻转
			}
			pic_buf_ptr += 3;//三个字节一个颜色像素点
		}
		
	}   

	//显示图片路径名	
	wchar_t *w_pathname = NULL;
	if( mchars_to_wchars(pathname, &w_pathname) == 0)//将多字节转换为宽字符(汉字未能转换成功)
	{
		//显示字体
		Lcd_Show_FreeType(w_pathname,32,0x00,x_s+10,y_s+50, lcd_ptr);
		free(w_pathname);
	}
	
	free( ptr_save );
	return 0;
}

/*get_pic_data_to_buffer:获取图片的像素数据
 *pathname：图片的路径名
 *pic_buf_ptr：用来指向 存放图片的像素数据缓冲区
 */
int get_pic_data_to_buffer(const char *pathname, unsigned char **pic_buf_ptr)
{
    FILE *pic_fp;
	off_t file_size;
	struct stat file_info;
        
	pic_fp = fopen(pathname, "r");
	if(pic_fp == NULL)
	{
		perror("open %s error\n");
		return -1;
	}

	if( stat(pathname, &file_info) == -1)
	{
		perror("get file info error\n");
		return -1;
	}
	
	file_size = file_info.st_size;//获取图片大小
	*pic_buf_ptr = (unsigned char *)malloc(file_size-54);

	fseek(pic_fp, 54,SEEK_SET);//跳过文件头(存在内存对齐，可能是56字节)
	
	fread(*pic_buf_ptr, file_size-54, 1, pic_fp);//读取图片颜色数据
	if(ferror(pic_fp))
	{
			perror("read picture data error\n");
			return -1; 
	}

	return fclose(pic_fp);
    
}

/*get_bmp_width_and_height:获取bmp图片的宽高信息
 *pathname：图片路径名
 *width：图片的宽度
 *height：图片的高度
 */
int get_bmp_width_and_height(const char *pathname, unsigned int *width, unsigned int *height)
{
	FILE *pic_fp;
	unsigned char file_head[54];

	pic_fp = fopen(pathname, "r");
	if(pic_fp == NULL)
	{
		perror("open %s error\n");
		return -1;
	}

	fread( file_head, 54, 1, pic_fp);
	if( ferror( pic_fp ) )
	{
		perror("read picture head error\n");
		return -1;
	}
	fclose(pic_fp);
	
	*width = *((int*)&file_head[18]);//宽：18~21共4个字节
	*height = file_head[22] | file_head[23]<<8;//高：22~23共两个字节

	return 0;
}


