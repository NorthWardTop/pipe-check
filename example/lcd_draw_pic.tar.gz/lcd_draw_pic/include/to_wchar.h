#ifndef __TO_WCHAR_H_
#define __TO_WCHAR_H_

#include <wchar.h>

int mchars_to_wchars(const char *mbs_char, wchar_t **w_char);

#endif /* end with #ifndef __TO_WCHAR_H_ */
