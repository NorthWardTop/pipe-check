#ifndef __DISPLAY_BMP__H
#define	__DISPLAY_BMP__H

extern int get_bmp_width_and_height(const char *pathname, unsigned int *width, unsigned int *height);

extern int display_bmp(const char *pathname, unsigned int *lcd_ptr, unsigned int x_s, unsigned int y_s);

extern int get_pic_data_to_buffer(const char *pathname, unsigned char **pic_buffer);


#endif /*end define __DISPLAY_BMP__H */
