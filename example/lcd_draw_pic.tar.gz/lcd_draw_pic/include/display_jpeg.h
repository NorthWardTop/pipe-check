#ifndef __DISPALY_JPEG_H_
#define __DISPALY_JPEG_H_

int display_jpeg(char * filename, unsigned int *lcd_ptr, unsigned int x_s, unsigned int y_s);

#endif /* end with #ifndef __DISPLAY_JPEG_H_ */
